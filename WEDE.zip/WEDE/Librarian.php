<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Librarian</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--hi-->
            <link rel="stylesheet" type="text/css" href="CSS/librarianStyle.css">

    </head>
    <body>
       <div class="container">
           <div class="Navi-bar">
                <div class="topnav">
                <table>
                    <tr>
                        <td>
                            <img src="Images/BookSale-logos_black.png" height="100" width="100">
                        </td>
                        <td>
                            <a href="verifyStudents.html">Verify Students</a>
                        </td>
                        <td>
                            <a href="bookList.html">Book List</a>
                        </td>
                        <td>
                            <a href="verifyBooks.html">Verify Books</a>
                        </td>
                        <td>
                            <a href="orders.html">Orders</a>
                        </td>        
                        <td>
                            <a class="active" href="librarian.html">Profile</a>
                        </td>
                        <td>
                            <a href="adminPage.html">
                            <button class="button" >LOGOUT</button>
                            </a>
                        </td>
                    </tr>
            </table>
            </div>
           </div>
           <div class="Body">
               <table>
                   <tr>
                            <td>
                                <p>Profile picture</p>
                            </td>
                            <td>
                                <img src="Images/proflie-pic.png" height="160" width="160">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>First Name:</p>
                            </td>
                            <td>
                                <input type="text" placeholder="eg. John"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Surname:</p>
                            </td>
                            <td>
                                <input type="text" placeholder="eg. Oreo"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Student Number:</p>
                            </td>
                            <td>
                                <input type="text" placeholder="eg. AdminNumber"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>ID Number:</p>
                            </td>
                            <td>
                                <input type="number" placeholder="eg. 1234567891230"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Password:</p>
                            </td>
                            <td>
                                <input type="password" placeholder="eg. **********"/>
                            </td>
                            <td>
                                <button class="button">SAVE</button>
                            </td>
                        </tr>
               </table>
           </div>
  <div class="Footer">
      <p>Book Sale is powered by our students</p>
  </div>
</div>
    </body>
</html>
