<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Student Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="CSS/sellerStyle.css">
    </head>
    <body>
        <div class="container">
            <div class="Navi-bar">
                <div class="topnav">
                    <table>
                    <tr>
                        <td>
                            <img src="Images/BookSale-logos_black.png" height="100" width="100">
                        </td>
                        <td>
                            <a href="Home.html">Home</a>
                        </td>
                        <td>
                            <a href="Contact-Us.html">Contact Us</a>
                        </td>
                        <td>
                            <a class="active" href="studentPage.html">Profile</a>
                        </td>        
                        <td><form>
                                <table>
                                    <tr>
                                        <td>
                                            <input type="text" placeholder="Book Name,Code">
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </td>
                            <td>
                                <a href="Log.html">
                                <button class="button" >LOGOUT</button>
                                </a>
                            </td>
                    </tr>
            </table>
                </div>
            </div>
            <div class="Body">
                <form>
                    <table class="tab">
                        <tr>
                            <td>
                                <p>Profile picture</p>
                            </td>
                            <td>
                                <img src="Images/proflie-pic.png" height="160" width="160">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>First Name:</p>
                            </td>
                            <td>
                                <input type="text" placeholder="eg. John"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Surname:</p>
                            </td>
                            <td>
                                <input type="text" placeholder="eg. Oreo"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Student Number:</p>
                            </td>
                            <td>
                                <input type="text" placeholder="eg. ST0000000"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>ID Number:</p>
                            </td>
                            <td>
                                <input type="number" placeholder="eg. 1234567891230"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Password:</p>
                            </td>
                            <td>
                                <input type="password" placeholder="eg. **********"/>
                            </td>
                            <td>
                                <button>SAVE</button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Upload Books</p>
                            </td>
                            <td>
                                <img src="Images/img1.jpg" height="160" width="160">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p>Chart</p>
                            </td>
                            <td>
                                <a href="ordersSt.html">
                                    <img src="Images/trolly.png" height="160" width="160">
                                </a>
                                
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            <div class="Footer">
                <p>Book Sale is powered by our students</p>
            </div>
        </div>
    </body>
</html>
