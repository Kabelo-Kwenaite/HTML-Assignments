
<?php
include("DBconn.php");

$errorCount = 0;
$fname_error = $lname_error = $idNum_error = $email_error = $msg_error = $password_error = "";
$fname = $lname = $idNum = $msg = $email = $password = "";


if(isset($_POST["submit"])){
   if(empty($_POST['firstName'])){
     $fname_error = "Please insert the first name.";
     $errorCount++;
   }else{
     $fname = $_POST['firstName'];
   }

   if(empty($_POST['lastName'])){
     $lname_error = "Please insert the last name.";
     $errorCount++;
   }else{
     $lname = $_POST['lastName'];
   }

   if(empty($_POST['email'])){
    $email_error = "Please insert email address";
    $errorCount++;
  }else{
    $email = $_POST['email'];
  }
   if(empty($_POST['idNum'])){
     $idNum_error = "Please insert the ID Number.";
     $errorCount++;
   }else{
     $idNum = $_POST['idNum'];
   }
   if(empty($_POST['password'])){
    $password_error = "Please insert the password.";
    $errorCount++;
   }else{
    $password = $_POST['password'];
   }


   if($errorCount == 0){
   //query for inserting into a table
   $sql = "INSERT INTO tblUser (userID, firstname, lastname, email, idnumber, password)
       VALUES (null,'$fname', '$lname', '$email', '$idNum','$password')";
   

     //executing the query
     $dbResult = mysqli_query($dbconnect, $sql);

     if ($dbResult === FALSE) {
       echo "Error inserting details into the database: ". mysqli_connect_error();
     } else { 
       echo "User details saved successfully.";
     }

     $fname = $lname = $idNum = $msg = $email = "";

       //closing the database connection
       mysqli_close($dbconnect);
       $dbconnect = FALSE;
   }
}

 unset($_POST["submit"]);
?>
