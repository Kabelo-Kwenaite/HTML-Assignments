<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Verify Students</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="CSS/verifyStudents.css">

    </head>
    <body>
        <div class="container">
            <div class="Navi-bar">
                <div class="topnav">
                    <table>
                        <tr>
                            <td>
                                <img src="Images/BookSale-logos_black.png" height="100" width="100">
                            </td>
                            <td>
                                <a class="active" href="verifyStudents.html">Verify Students</a>
                            </td>
                            <td>
                                <a href="bookList.html">Book List</a>
                            </td>
                            <td>
                                <a href="verifyBooks.html">Verify Books</a>
                            </td>
                            <td>
                                <a href="orders.html">Orders</a>
                            </td>        
                            <td>
                                <a href="librarian.html">Profile</a>
                            </td>
                            <td>
                                <a href="adminPage.html">
                                <button class="button" >LOGOUT</button>
                                </a>
                            </td>
                        </tr>
            </table>
                </div>
            </div>
            <div class="Body">
                <form>
                    <table>
                        <tr>
                            <td>
                <label>Verify Student list: </label>
                            </td>
                            <td>
                <select name="stNumber" id="stNumbers">
                    <option value="Null">Student Number</option>
                    <option value="52">ST10118297</option>
                </select>
                    </td>
                    </tr>
                    <tr>
                        <td>

                        </td>
                        <td>

                        </td>
                    </tr>
                    <tr>
                        <td>
                           <label>Student Name:</label> 
                        </td>
                        <td>
                            <input type="text" id="stName">
                        </td>
                    </tr>
                    <tr>
                        <td>

                        </td>
                        <td>
                            
                        </td>
                    </tr>
                <tr>
                        <td>
                            <label>Student Surname:</label>
                        </td>
                        <td>
                            <input type="text" id="stSurame">
                        </td>
                    </tr>
                    <tr>
                        <td>

                        </td>
                        <td>
                            
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>Student Number:</label>
                        </td>
                        <td>
                            <input type="text" id="stNumber">
                        </td>
                    </tr>
                    <tr>
                        <td>
                        
                        </td>
                        <td>
                            <button class="button">Verify</button>
                        </td>
                    </tr>
                    <tr>
                    </table>
                </form>
            </div>
            <div class="Footer">
                <p>Book Sale is powered by our students</p>
            </div>
        </div>
    </body>
</html>
