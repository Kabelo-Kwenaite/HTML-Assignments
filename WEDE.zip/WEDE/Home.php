<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Book Sale</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="CSS/homeStyle.css">
    </head>
    <body>
        <div class="container">
            <div class="Navi-bar">
                <div class="topnav">
                <table>
                    <tr>
                        <td>
                            <img src="Images/BookSale-logos_black.png" height="100" width="100">
                        </td>
                        <td>
                            <a class="active" href="Home.html">Home</a>
                        </td>
                        <td>
                            <a href="Contact-Us.html">Contact Us</a>
                        </td>
                        <td>
                            <a href="studentPage.html">Profile</a>
                        </td>        
                        <td><form>
                                <table>
                                    <tr>
                                        <td>
                                           <input type="text" placeholder="Book Name,Code"> 
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </td>
                    </tr>
            </table>
            </div>
                </div>
            <div class="Body">
                <table class="tables">
                    <tr>
                        <td>
                <ul>
                    <li>
                        <img src="Images/img1.jpg" width="150" height="150">
                        <h4>Book Title</h4>
                        <p>Module Name or Code</p>
                        <p>Price</p>
                    </li>
                    <li>
                        <img src="Images/img2.jpg" width="150" height="150">
                        <h4>Book Title</h4>
                        <p>Module Name or Code</p>
                        <p>Price</p>
                    </li>
                    <li>
                        <img src="Images/img3.jpg" width="150" height="150">
                        <h4>Book Title</h4>
                        <p>Module Name or Code</p>
                        <p>Price</p>
                    </li>
                    <li>
                        <img src="Images/img4.jpg" width="190" height="150">
                       <h4>Book Title</h4>
                        <p>Module Name or Code</p>
                        <p>Price</p>
                    </li>
                    <li>
                        <img src="Images/img5.jpg" width="150" height="150">
                        <h4>Book Title</h4>
                        <p>Module Name or Code</p>
                        <p>Price</p>
                    </li>
                    
                </ul>
                        </td>

                </tr>
                </table>
            </div>
  <div class="Footer">
      <p>Book Sale is powered by our students</p>
  </div>
  
</div>
    </body>
</html>
