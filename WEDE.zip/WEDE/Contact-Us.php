<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Contact</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="CSS/contactStyle.css">
    </head>
    <body>
        <div class="container">
            <div class="Navi-bar">
                <div class="topnav">
                <table>
                    <tr>
                        <td>
                            <img src="Images/BookSale-logos_black.png" height="100" width="100">
                        </td>
                        <td>
                            <a  href="Home.html">Home</a>
                        </td>
                        <td>
                            <a class="active" href="Contact-Us.html">Contact Us</a>
                        </td>
                        <td>
                            <a href="studentPage.html">Profile</a>
                        </td>        
                        <td><form>
                                <table>
                                    <tr>
                                        <td>
                                           <input type="text" placeholder="Book Name,Code"> 
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </td>
                    </tr>
            </table>
            </div>
                </div>
            <div class="Body">
                <table class="tab">
                    <tr>
                        <td>
                            <label>Full Name:</label>
                        </td>
                        <td>
                            <input type="text" placeholder="John Oreo">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>Email Address:</label>
                        </td>
                        <td>
                            <input type="text" placeholder="Student Email">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>Message:</label>
                        </td>
                        <td>
                            <textarea name="message" rows="10" cols="30">
                            </textarea>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <button>SUBMIT</button>
                        </td>
                    </tr>
                </table>

            </div>
  <div class="Footer">
      <p>Book Sale is powered by our students</p>
  </div>
  
</div>
    </body>
</html>
