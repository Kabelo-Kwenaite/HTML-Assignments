<html>
    <head>
        <title>Secondhand</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="CSS/style.css">
    <style>
        body{
            background-color: #ADD8E6
        }
    </style>
    <body>
 <div class="container">
	<div class="screen">
		<div class="screen__content">
			<form class="login" action="home.html">
				<div class="login__field">
					<i class="login__icon fas fa-user"></i>
					<input type="text" class="login__input" placeholder="User name / Email">
				</div>
				<div class="login__field">
					<i class="login__icon fas fa-lock"></i>
					<input type="password" class="login__input" placeholder="Password">
				</div>
                            <div class="login__field">
					<i class="login__icon fas fa-lock"></i>
                                        <a href="Forgot password.html">Forgot password</a>
                                        <i class="login__icon fas fa-lock"></i>
                                        <a href="adminPage.html">Admin page</a>
				</div>
                            
				<button class="button login__submit">
					<span class="button__text">LOGIN</span>
					<i class="button__icon fas fa-chevron-right"></i>
				</button>
                            <button class="button login__submit" type="button" onclick="window.location.href='Register page.php';">
					<span class="button__text">CREATE ACCOUNT</span>
					<i class="button__icon fas fa-chevron-right"></i>
				</button>
			</form>
			<div class="social-login">
				
				<div class="social-icons">
					<img src="images/BookSale-logos_transparent.png" width="200" height="150">
				</div>
			</div>
		</div>
		<div class="screen__background">
			<span class="screen__background__shape screen__background__shape4"></span>
			<span class="screen__background__shape screen__background__shape3"></span>		
			<span class="screen__background__shape screen__background__shape2"></span>
			<span class="screen__background__shape screen__background__shape1"></span>
		</div>		
	</div>
</div>

        </body>
</html>