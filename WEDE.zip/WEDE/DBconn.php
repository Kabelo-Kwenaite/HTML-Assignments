<?php
$conn = new mysqli('localhost','root','','bookstore');
if($conn === false){
    echo "connection falied";
}
?>