<?php 
include("processRegi.php");
?>
<!DOCTYPE html>
<html><head>
        <title>Register Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link rel="stylesheet" type="text/css" href="CSS/style.css">

    </head>
    <body>
 <div class="container">
	<div class="screen">
		<div class="screen__content">
			<form class="login" action="" method="POST">
                            <table>
                                <tr>
                                    <td>
                                        <i class="login__icon fas fa-user"></i>
					<input type="text" class="login__input" placeholder="First name"><span><?=$fname_error?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <i class="login__icon fas fa-user"></i>
					<input type="text" class="login__input" placeholder="Surname"><span><?=$lname_error?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <i class="login__icon fas fa-user"></i>
					<input type="text" class="login__input" placeholder="Email"><span><?=$email_error?></span>
                                    </td>
                                </tr><tr>
                                    <td>
                                        <i class="login__icon fas fa-user"></i>
					<input type="text" class="login__input" placeholder="ID number"><<span><?=$idNum_error?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <i class="login__icon fas fa-lock"></i>
					<input type="password" class="login__input" placeholder="Password"><span><?=$password_error?></span>
                                    </td>
                                </tr><tr>
                                    <td>
                                        <i class="login__icon fas fa-lock"></i>
					<input type="password" class="login__input" placeholder="Confirm Password">
                                    </td>
                                </tr>
                                
                            </table>
				<button type="submit" class="button login__submit" value="Submit" name="submit">
					<span class="button__text">Register</span>
					<i class="button__icon fas fa-chevron-right"></i>
				</button>
			</form>
			<div class="social-login">
				
				<div class="social-icons">
					<img src="images/BookSale-logos_transparent.png" width="200" height="150">
				</div>
			</div>
		</div>
		<div class="screen__background">
			<span class="screen__background__shape screen__background__shape4"></span>
			<span class="screen__background__shape screen__background__shape2"></span>
			<span class="screen__background__shape screen__background__shape1"></span>
		</div>		
	</div>
</div>
    </body>
</html>